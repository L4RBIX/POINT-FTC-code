package org.firstinspires.ftc.teamcode.TeleOps;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.eventloop.opmode.*;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.teamcode.Controllers.*;
@Config
@TeleOp(name = "MainTeleOp")
public class Fulltest extends LinearOpMode {

    private DcMotor shooterMotor1;
    private DcMotor shooterMotor2;
    private MecanumDrive drive = new MecanumDrive();
    private Intake_roller intake = new Intake_roller();
    Flywheel flywheel;


    double intakePower = 1.0;
    double turretPower = 0.7;
    private static final double SHOOTER_POWER = 1.0;
    private static final double SERVO_LEFT_POS = 0.2;
    private static final double SERVO_RIGHT_POS = 0.55;
    private static final double SERVO_CENTER_POS = 0.5;
    private static final double SERVO_REST = 0.35;


    @Override
    public void runOpMode() {

        drive.init(hardwareMap);
        intake.init(hardwareMap);
        flywheel = new Flywheel(hardwareMap, telemetry);
        Flywheel.targetVelocity = 1500;





        waitForStart();

        while (opModeIsActive()) {

            // ===== MECANUM DRIVE =====
            drive.drive(
                    -gamepad1.left_stick_y,
                    gamepad1.left_stick_x,
                    gamepad1.right_stick_x
            );

// ===== INTAKE CONTROL =====
            if (gamepad1.right_trigger > 0.1) {
                intake.forward(intakePower);
            }
            else if (gamepad1.left_trigger > 0.1) {
                intake.backward(intakePower);
            }
            else {
                intake.stop();
            }

// ===== ROLLER CONTROL =====
            // ===== ROLLER CONTROL =====
            if (gamepad1.right_bumper) {
                intake.rollerForward(intakePower);
            }
            else if (gamepad1.left_bumper) {
                intake.rollerstop(0);  // This explicitly stops
            }
            else {
                intake.rollerstop(0);  // ADD THIS - stops when no bumper is pressed
            }


// A button - move servo one direction
            if (gamepad1.x) {
                flywheel.setMidRange();    // 1200 tps
            } else if (gamepad1.y) {
                flywheel.setEdgeZone();    // 1450 tps
            } else if (gamepad1.b) {
                flywheel.setHighRange();   // 1700 tps
            }


// Add telemetry for servo position
            if (gamepad1.dpad_up) {
                Flywheel.targetVelocity += 50; // Increase by 50 tps
                flywheel.start();
            }

            // Decrease speed with D-pad down
            if (gamepad1.dpad_down) {
                Flywheel.targetVelocity -= 50; // Decrease by 50 tps
                if (Flywheel.targetVelocity < 0) {
                    Flywheel.targetVelocity = 0;
                    flywheel.stop();
                }
            }
            // Update flywheel (IMPORTANT - call every loop!)
            flywheel.update();

            telemetry.addData("Shooter Servo Position", "%.4f", flywheel.getServoPosition());
            telemetry.addData("Flywheel RPM", "%.4f", flywheel.getCurrentVelocity());

            telemetry.update();
        }
    }
}
