package org.firstinspires.ftc.teamcode.Controllers;

import com.qualcomm.robotcore.hardware.*;

public class MecanumDrive {

    private DcMotorEx fl, fr, bl, br;

    public void init(HardwareMap hw) {
        fl = hw.get(DcMotorEx.class, "fl");
        fr = hw.get(DcMotorEx.class, "fr");
        bl = hw.get(DcMotorEx.class, "bl");
        br = hw.get(DcMotorEx.class, "br");

        fl.setDirection(DcMotorSimple.Direction.REVERSE);
        bl.setDirection(DcMotorSimple.Direction.REVERSE);

        setBrake(true);
    }

    public void drive(double y, double x, double rx) {
        double denom = Math.max(Math.abs(y) + Math.abs(x) + Math.abs(rx), 1);

        double flP = (y + x + rx) / denom;
        double blP = (y - x + rx) / denom;
        double frP = (y - x - rx) / denom;
        double brP = (y + x - rx) / denom;

        fl.setPower(flP);
        bl.setPower(blP);
        fr.setPower(frP);
        br.setPower(brP);
    }

    public void stop() {
        fl.setPower(0);
        fr.setPower(0);
        bl.setPower(0);
        br.setPower(0);
    }

    private void setBrake(boolean brake) {
        DcMotor.ZeroPowerBehavior b =
                brake ? DcMotor.ZeroPowerBehavior.BRAKE : DcMotor.ZeroPowerBehavior.FLOAT;

        fl.setZeroPowerBehavior(b);
        fr.setZeroPowerBehavior(b);
        bl.setZeroPowerBehavior(b);
        br.setZeroPowerBehavior(b);
    }
}
