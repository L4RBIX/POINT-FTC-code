package org.firstinspires.ftc.teamcode.TeleOps;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.teamcode.Controllers.MecanumAndAlignment;
import org.firstinspires.ftc.teamcode.Controllers.MecanumDrive;

@TeleOp(name = "Alignment Test")
public class AlignmentTest extends LinearOpMode {

    private MecanumAndAlignment drive;
    private boolean autoAligning = false;

    @Override
    public void runOpMode() {
        drive = new MecanumAndAlignment();
        drive.init(hardwareMap);

        telemetry.addData("Status", "Initialized");
        telemetry.addData("Controls", "");
        telemetry.addData("  Left Stick", "Drive");
        telemetry.addData("  Right Stick X", "Turn");
        telemetry.addData("  A Button", "Auto-Align to Target");
        telemetry.addData("  Y Button", "Reset Position");
        telemetry.addData("", "");
        telemetry.addData("Target", "(-355, 355) mm");
        telemetry.update();

        waitForStart();

        while (opModeIsActive()) {

            // ===== ALIGNMENT CONTROL =====
            // Press A to start/stop alignment
            if (gamepad1.a && !autoAligning) {
                autoAligning = true;
                gamepad1.rumble(100); // Short vibration to confirm
                sleep(200); // Debounce
            }

            // Press B to cancel alignment
            if (gamepad1.b && autoAligning) {
                autoAligning = false;
                drive.stop();
                gamepad1.rumble(50, 50, 100); // Different pattern for cancel
                sleep(200);
            }

            // Reset position with Y button
            if (gamepad1.y) {
                drive.resetPosition();
                telemetry.addData("Action", "Position Reset!");
                gamepad1.rumble(200);
                sleep(300);
            }

            // ===== DRIVE CONTROL =====
            if (autoAligning) {
                // Auto-align to target
                boolean aligned = drive.alignToTarget();

                if (aligned) {
                    telemetry.addData("═══════════════", "");
                    telemetry.addData("STATUS", "✓✓✓ ALIGNED ✓✓✓");
                    telemetry.addData("═══════════════", "");
                    gamepad1.rumble(500); // Long vibration when aligned
                    autoAligning = false; // Stop aligning once reached
                } else {
                    telemetry.addData("Status", ">>> ALIGNING <<<");
                }
            } else {
                // Manual drive control
                drive.drive(
                        -gamepad1.left_stick_y,   // Forward/backward
                        gamepad1.left_stick_x,    // Strafe left/right
                        gamepad1.right_stick_x    // Turn
                );
                telemetry.addData("Status", "Manual Control");
            }

            // ===== TELEMETRY =====
            Pose2D currentPos = drive.getPosition();
            double currentX = currentPos.getX(DistanceUnit.MM);
            double currentY = currentPos.getY(DistanceUnit.MM);
            double currentHeading = currentPos.getHeading(AngleUnit.DEGREES);

            // Calculate distance to target
            double errorX = -355 - currentX;
            double errorY = 355 - currentY;
            double distanceToTarget = Math.sqrt(errorX * errorX + errorY * errorY);

            telemetry.addData("", "");
            telemetry.addData("─── POSITION ───", "");
            telemetry.addData("Current X", "%.1f mm", currentX);
            telemetry.addData("Current Y", "%.1f mm", currentY);
            telemetry.addData("Heading", "%.1f°", currentHeading);
            telemetry.addData("", "");
            telemetry.addData("─── TARGET ───", "");
            telemetry.addData("Target X", "-355 mm");
            telemetry.addData("Target Y", "355 mm");
            telemetry.addData("Distance to Target", "%.1f mm", distanceToTarget);
            telemetry.addData("", "");
            telemetry.addData("─── CONTROLS ───", "");
            telemetry.addData("A Button", autoAligning ? "[ACTIVE]" : "Start Align");
            telemetry.addData("B Button", "Cancel Align");
            telemetry.addData("Y Button", "Reset Position");

            telemetry.update();
        }
    }
}