package org.firstinspires.ftc.teamcode.Controllers;

import com.qualcomm.robotcore.hardware.*;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;

import org.firstinspires.ftc.teamcode.Controllers.GoBildaPinpointDriver;


public class  MecanumAndAlignment {

    private DcMotorEx fl, fr, bl, br;
    private GoBildaPinpointDriver pinpoint;

    // Target coordinates
    private static final double TARGET_X = -355; // mm
    private static final double TARGET_Y = 355;  // mm

    // PID constants for alignment (tune these!)
    public static double ALIGN_KP = 0.008;
    public static double ALIGN_MAX_POWER = 0.6;
    public static double POSITION_TOLERANCE = 20; // mm
    public static double HEADING_KP = 0.015;
    public static double HEADING_TOLERANCE = 2; // degrees

    public void init(HardwareMap hw) {
        fl = hw.get(DcMotorEx.class, "fl");
        fr = hw.get(DcMotorEx.class, "fr");
        bl = hw.get(DcMotorEx.class, "bl");
        br = hw.get(DcMotorEx.class, "br");

        fl.setDirection(DcMotorSimple.Direction.REVERSE);
        bl.setDirection(DcMotorSimple.Direction.REVERSE);

        setBrake(true);

        // Initialize Pinpoint (reads from both odometry pods)
        pinpoint = hw.get(GoBildaPinpointDriver.class, "pinpoint");

        // IMPORTANT: Measure and set your odometry pod offsets!
        // X offset: horizontal distance from robot center (left is negative, right is positive)
        // Y offset: vertical distance from robot center (forward is positive, back is negative)
        pinpoint.setOffsets(-84.0, -168.0); // CHANGE THESE TO YOUR ROBOT'S MEASUREMENTS

        // Set encoder directions (change if wheels go backwards)
        pinpoint.setEncoderDirections(
                GoBildaPinpointDriver.EncoderDirection.FORWARD,
                GoBildaPinpointDriver.EncoderDirection.FORWARD
        );

        // Set encoder resolution for goBILDA 4-bar pods
        pinpoint.setEncoderResolution(GoBildaPinpointDriver.goBILDA_4_BAR_POD);

        // Reset position to (0, 0, 0°)
        pinpoint.resetPosAndIMU();
    }

    public void drive(double y, double x, double rx) {
        double denom = Math.max(Math.abs(y) + Math.abs(x) + Math.abs(rx), 1);

        double flP = (y + x + rx) / denom;
        double blP = (y - x + rx) / denom;
        double frP = (y - x - rx) / denom;
        double brP = (y + x - rx) / denom;

        fl.setPower(flP);
        bl.setPower(blP);
        fr.setPower(frP);
        br.setPower(brP);
    }

    /**
     * Align robot to target (-355, 355) using robot-centric control
     * Pinpoint automatically uses both odometry pods + IMU
     * @return true if aligned
     */
    public boolean alignToTarget() {
        // Update position from both odometry pods
        pinpoint.update();
        Pose2D currentPos = pinpoint.getPosition();

        // Get current position (X pod data + Y pod data combined)
        double currentX = currentPos.getX(DistanceUnit.MM);
        double currentY = currentPos.getY(DistanceUnit.MM);
        double currentHeading = currentPos.getHeading(AngleUnit.RADIANS);

        // Calculate error to target
        double errorX = TARGET_X - currentX;
        double errorY = TARGET_Y - currentY;
        double distance = Math.sqrt(errorX * errorX + errorY * errorY);

        // Calculate angle to target
        double angleToTarget = Math.atan2(errorY, errorX);

        // Calculate heading error
        double headingError = angleToTarget - currentHeading;
        while (headingError > Math.PI) headingError -= 2 * Math.PI;
        while (headingError < -Math.PI) headingError += 2 * Math.PI;

        // Convert to robot-relative coordinates
        double robotRelativeX = errorX * Math.cos(-currentHeading) - errorY * Math.sin(-currentHeading);
        double robotRelativeY = errorX * Math.sin(-currentHeading) + errorY * Math.cos(-currentHeading);

        // Check if aligned
        if (distance < POSITION_TOLERANCE && Math.abs(Math.toDegrees(headingError)) < HEADING_TOLERANCE) {
            stop();
            return true;
        }

        // Calculate control
        double forwardPower = clamp(robotRelativeY * ALIGN_KP, -ALIGN_MAX_POWER, ALIGN_MAX_POWER);
        double strafePower = clamp(robotRelativeX * ALIGN_KP, -ALIGN_MAX_POWER, ALIGN_MAX_POWER);
        double turnPower = clamp(headingError * HEADING_KP, -ALIGN_MAX_POWER, ALIGN_MAX_POWER);

        drive(forwardPower, strafePower, turnPower);
        return false;
    }

    public Pose2D getPosition() {
        pinpoint.update();
        return pinpoint.getPosition();
    }

    public void resetPosition() {
        pinpoint.resetPosAndIMU();
    }

    private double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    public void stop() {
        fl.setPower(0);
        fr.setPower(0);
        bl.setPower(0);
        br.setPower(0);
    }

    private void setBrake(boolean brake) {
        DcMotor.ZeroPowerBehavior b =
                brake ? DcMotor.ZeroPowerBehavior.BRAKE : DcMotor.ZeroPowerBehavior.FLOAT;

        fl.setZeroPowerBehavior(b);
        fr.setZeroPowerBehavior(b);
        bl.setZeroPowerBehavior(b);
        br.setZeroPowerBehavior(b);
    }
}