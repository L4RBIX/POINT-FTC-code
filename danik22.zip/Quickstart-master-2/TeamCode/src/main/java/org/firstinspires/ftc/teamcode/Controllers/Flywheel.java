package org.firstinspires.ftc.teamcode.Controllers;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.Telemetry;
@Config
public class Flywheel {
    // Tuned PIDF coefficients
    public static double kP = 0.0002;
    public static double kI = 0.0;
    public static double kD = 0.00007;
    public static double kF = 0.000425;

    public static double targetVelocity = 0; // Target velocity in ticks per second

    // Preset velocities for different zones
    public static double MID_RANGE_VELOCITY = 1200;
    public static double EDGE_ZONE_VELOCITY = 1450;
    public static double HIGH_RANGE_VELOCITY = 1700;

    private static final double VELOCITY_TOLERANCE = 50; // RPM tolerance for "at target"
    private static final double SERVO_INCREMENT = 0.01;

    private DcMotorEx leftMotor;
    private DcMotorEx rightMotor;
    private PIDFController pid;
    private Telemetry telemetry;
    private Servo shooterServo;
    private Gamepad gamepad; // For vibration

    private boolean isRunning = false;
    private boolean wasAtTarget = false; // Track if we already vibrated

    public Flywheel(HardwareMap hardwareMap, Telemetry telemetry) {
        this.telemetry = telemetry;
        this.gamepad = gamepad;

        // Initialize motors
        leftMotor = hardwareMap.get(DcMotorEx.class, "leftShooter");
        rightMotor = hardwareMap.get(DcMotorEx.class, "rightShooter");

        shooterServo = hardwareMap.get(Servo.class, "shooterServo");

        // Reverse one motor
        leftMotor.setDirection(DcMotorSimple.Direction.REVERSE);

        // Set to RUN_USING_ENCODER for velocity control
        leftMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        // Set zero power behavior
        leftMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
        rightMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);

        // Initialize PID controller
        pid = new PIDFController(kP, kI, kD, kF);
    }

    /**
     * Set flywheel to mid-range velocity (1200 tps)
     */
    public void setMidRange() {
        targetVelocity = MID_RANGE_VELOCITY;
        start();
        wasAtTarget = false;
    }

    /**
     * Set flywheel to edge zone velocity (1450 tps)
     */
    public void setEdgeZone() {
        targetVelocity = EDGE_ZONE_VELOCITY;
        start();
        wasAtTarget = false;
    }

    /**
     * Set flywheel to high range velocity (1700 tps)
     */
    public void setHighRange() {
        targetVelocity = HIGH_RANGE_VELOCITY;
        start();
        wasAtTarget = false;
    }

    /**
     * Start the flywheel at the target velocity
     */
    public void start() {
        isRunning = true;
    }

    /**
     * Start the flywheel at a specific velocity
     * @param velocity Target velocity in ticks per second
     */
    public void start(double velocity) {
        targetVelocity = velocity;
        isRunning = true;
        wasAtTarget = false;
    }

    /**
     * Stop the flywheel
     */
    public void stop() {
        isRunning = false;
        leftMotor.setPower(0);
        rightMotor.setPower(0);
        pid.reset();
        wasAtTarget = false;
    }

    /**
     * Set target velocity without starting
     * @param velocity Target velocity in ticks per second
     */
    public void setTargetVelocity(double velocity) {
        targetVelocity = velocity;
    }

    /**
     * Update the flywheel - call this in your main loop
     */
    public void update() {
        // Update PID coefficients (for dashboard tuning)
        pid.setPIDF(kP, kI, kD, kF);
        telemetry.addData("Shooter Servo Pos", "%.4f", shooterServo.getPosition());

        if (isRunning && targetVelocity != 0) {
            // Get current velocity (average of both motors)
            double leftVelocity = leftMotor.getVelocity();
            double rightVelocity = rightMotor.getVelocity();
            double currentVelocity = (leftVelocity + rightVelocity) / 2.0;

            // Calculate power using PIDF
            double power = pid.calculate(currentVelocity, targetVelocity);

            // Apply power to both motors
            leftMotor.setPower(power);
            rightMotor.setPower(power);

            // Check if at target velocity and vibrate
            boolean atTarget = atTargetVelocity(VELOCITY_TOLERANCE);
            if (atTarget && !wasAtTarget) {
                // Just reached target - vibrate controller
                vibrateController();
                wasAtTarget = true;
            } else if (!atTarget) {
                wasAtTarget = false;
            }

            // Telemetry
            telemetry.addData("Flywheel Status", atTarget ? "✓ READY" : "SPINNING UP");
            telemetry.addData("Target Velocity", "%.0f tps", targetVelocity);
            telemetry.addData("Current Velocity", "%.0f tps", currentVelocity);
            telemetry.addData("Left Velocity", "%.0f tps", leftVelocity);
            telemetry.addData("Right Velocity", "%.0f tps", rightVelocity);
            telemetry.addData("Motor Power", "%.3f", power);
            telemetry.addData("Velocity Error", "%.0f tps", targetVelocity - currentVelocity);
        } else {
            telemetry.addData("Flywheel Status", "STOPPED");
        }
    }

    /**
     * Vibrate the controller to indicate ready status
     */
    private void vibrateController() {
        if (gamepad != null) {
            gamepad.rumble(500); // Vibrate for 500ms
        }
    }

    /**
     * Check if flywheel is at target velocity (within tolerance)
     * @param tolerance Acceptable error in ticks per second
     * @return true if at target
     */
    public boolean atTargetVelocity(double tolerance) {
        if (!isRunning) return false;

        double currentVelocity = (leftMotor.getVelocity() + rightMotor.getVelocity()) / 2.0;
        return Math.abs(targetVelocity - currentVelocity) < tolerance;
    }

    /**
     * Get current average velocity
     */
    public double getCurrentVelocity() {
        return (leftMotor.getVelocity() + rightMotor.getVelocity()) / 2.0;
    }

    /**
     * Check if flywheel is running
     */
    public boolean isRunning() {
        return isRunning;
    }

    /**
     * Adjust servo position incrementally
     * @param increment positive to increase, negative to decrease
     */
    public void adjustServo(double increment) {
        double currentPos = shooterServo.getPosition();
        double newPos = Math.max(0.0, Math.min(1.0, currentPos + increment));
        shooterServo.setPosition(newPos);
    }

    /**
     * Get current servo position
     */
    public double getServoPosition() {
        return shooterServo.getPosition();
    }
}