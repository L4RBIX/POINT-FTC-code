package org.firstinspires.ftc.teamcode.Controllers;

import com.qualcomm.robotcore.util.ElapsedTime;

public class PIDFController {
    private double kP, kI, kD, kF;
    private double lastError = 0;
    private double integral = 0;
    private ElapsedTime timer = new ElapsedTime();

    public PIDFController(double kP, double kI, double kD, double kF) {
        this.kP = kP;
        this.kI = kI;
        this.kD = kD;
        this.kF = kF;
        timer.reset();
    }

    public void setPIDF(double kP, double kI, double kD, double kF) {
        this.kP = kP;
        this.kI = kI;
        this.kD = kD;
        this.kF = kF;
    }

    public double calculate(double current, double target) {
        double error = target - current;
        double dt = timer.seconds();

        if (dt == 0) dt = 0.001; // Prevent division by zero

        timer.reset();

        integral += error * dt;
        double derivative = (error - lastError) / dt;
        lastError = error;

        return (kP * error) + (kI * integral) + (kD * derivative) + (kF * target);
    }

    public void reset() {
        lastError = 0;
        integral = 0;
        timer.reset();
    }
}